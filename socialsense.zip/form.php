<?php
	print_r($_REQUEST);
	echo gettype($_REQUEST['Filter']);
?>